

<?php $__env->startSection('content'); ?>

<div class="aiz-titlebar text-left mt-2 mb-3">
	<div class="align-items-center">
		<h1 class="h3"><?php echo e(translate('All Attributes')); ?></h1>
	</div>
</div>

<div class="row">
	<div class="col-md-7 col-xl-8">
		<div class="card">
			<div class="card-header">
				<h5 class="mb-0 h6"><?php echo e(translate('Attributes')); ?></h5>
			</div>
			<div class="card-body">
				<table class="table aiz-table mb-0">
					<thead>
						<tr>
							<th>#</th>
							<th><?php echo e(translate('Name')); ?></th>
							<th data-breakpoints="lg"><?php echo e(translate('Values')); ?></th>
							<th class="text-right"><?php echo e(translate('Actions')); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($key+1); ?></td>
								<td><?php echo e($attribute->getTranslation('name')); ?></td>
								<td>
									<?php $__currentLoopData = $attribute->attribute_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<span class="badge badge-inline badge-md bg-soft-dark mb-1"><?php echo e($value->getTranslation('name')); ?></span>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</td>
								<td class="text-right">
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('configure_attributes', Model::class)): ?>
										<a class="btn btn-soft-info btn-icon btn-circle btn-sm" href="<?php echo e(route('attributes.show', ['attribute'=>$attribute->id] )); ?>" title="<?php echo e(translate('Values')); ?>">
											<i class="las la-cog"></i>
										</a>
									<?php endif; ?>
									<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit_attributes', Model::class)): ?>
										<a class="btn btn-soft-primary btn-icon btn-circle btn-sm" href="<?php echo e(route('attributes.edit', ['id'=>$attribute->id, 'lang'=>env('DEFAULT_LANGUAGE')] )); ?>" title="<?php echo e(translate('Edit')); ?>">
											<i class="las la-edit"></i>
										</a>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<div class="aiz-pagination">
					<?php echo e($attributes->appends(request()->input())->links()); ?>

				</div>
			</div>
		</div>
	</div>
	<div class="col-md-5 col-xl-4">
		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add_attributes')): ?>
			<div class="card">
				<div class="card-header">
					<h5 class="mb-0 h6"><?php echo e(translate('Add New Attribute')); ?></h5>
				</div>
				<div class="card-body">
					<form action="<?php echo e(route('attributes.store')); ?>" method="POST">
						<?php echo csrf_field(); ?>
						<div class="alert alert-info">
							<?php echo e(translate('Attributes are non deletable. You can only add or edit.')); ?>

						</div>
						<div class="form-group mb-3">
							<label for="name"><?php echo e(translate('Name')); ?></label>
							<input type="text" placeholder="<?php echo e(translate('Name')); ?>" id="name" name="name" class="form-control" required>
						</div>
						<div class="form-group mb-3 text-right">
							<button type="submit" class="btn btn-primary"><?php echo e(translate('Add')); ?></button>
						</div>
					</form>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
    <?php echo $__env->make('backend.inc.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/schules1/a.schulesoft.com/resources/views/backend/product/attribute/index.blade.php ENDPATH**/ ?>