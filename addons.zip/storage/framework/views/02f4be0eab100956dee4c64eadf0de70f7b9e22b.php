<div class="form-group row gutters-10">
    <div class="col-xxl-3 col-xl-4 col-md-5 attr-names">
        <select class="form-control aiz-selectpicker" name="product_attributes[]" onchange="get_attributes_values(this)" data-live-search="true">
            <option value=""><?php echo e(translate('Select an attribute')); ?></option>
            <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($attribute->id); ?>"><?php echo e($attribute->getTranslation('name')); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col attr-values">
        <div class="form-control">
            <span><?php echo e(translate('Select an attribute')); ?></span>
        </div>
    </div>
    <div class="col-auto">
        <button type="button" data-toggle="remove-parent" class="btn btn-icon p-0" data-parent=".row">
            <i class="la-2x la-trash las opacity-70"></i>
        </button>
    </div>
</div><?php /**PATH /home/schules1/a.schulesoft.com/resources/views/backend/product/products/new_attribute.blade.php ENDPATH**/ ?>