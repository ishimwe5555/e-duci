<select class="form-control aiz-selectpicker" name="attribute_<?php echo e($attribute_id); ?>_values[]" multiple data-live-search="true">
    <?php $__currentLoopData = $attribute_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($attribute_value->id); ?>"><?php echo e($attribute_value->getTranslation('name')); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH /home/schules1/a.schulesoft.com/resources/views/backend/product/products/new_attribute_values.blade.php ENDPATH**/ ?>