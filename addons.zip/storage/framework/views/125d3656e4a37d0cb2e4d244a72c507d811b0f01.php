

<?php $__env->startSection('content'); ?>
    <div class="aiz-titlebar text-left mt-2 mb-3">
        <h1 class="mb-0 h6"><?php echo e(translate('Edit Product')); ?></h5>
    </div>
    <form class="form form-horizontal mar-top" action="<?php echo e(route('product.update', $product->id)); ?>" method="POST"
        enctype="multipart/form-data" id="product_form">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
        <input type="hidden" name="lang" value="<?php echo e($lang); ?>">
        <ul class="nav nav-tabs nav-fill border-light">
            <?php $__currentLoopData = \App\Models\Language::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <a class="nav-link text-reset <?php if($language->code == $lang): ?> active <?php else: ?> bg-soft-dark border-light border-left-0 <?php endif; ?> py-3"
                        href="<?php echo e(route('product.edit', ['id' => $product->id, 'lang' => $language->code])); ?>">
                        <img src="<?php echo e(static_asset('assets/img/flags/' . $language->flag . '.png')); ?>" height="11"
                            class="mr-1">
                        <span><?php echo e($language->name); ?></span>
                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="row gutters-5">
            <div class="col-lg">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Product Information')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Product Name')); ?> <span
                                    class="text-danger">*</span> <i class="las la-language text-danger"
                                    title="<?php echo e(translate('Translatable')); ?>"></i></label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="name"
                                    placeholder="<?php echo e(translate('Product Name')); ?>"
                                    value="<?php echo e($product->getTranslation('name', $lang)); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Unit')); ?> <i
                                    class="las la-language text-danger"
                                    title="<?php echo e(translate('Translatable')); ?>"></i></label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="unit"
                                    placeholder="<?php echo e(translate('Unit (e.g. 500 Gram, 2 Litre, 5 Pc etc)')); ?>"
                                    value="<?php echo e($product->getTranslation('unit', $lang)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Minimum Purchase Qty')); ?> <span
                                    class="text-danger">*</span></label>
                            <div class="col-md-8">
                                <input type="number" class="form-control" name="min_qty" min="1"
                                    value="<?php echo e($product->min_qty); ?>" required>
                                <small
                                    class="text-muted"><?php echo e(translate('Customer need to purchase this minimum quantity for this product. Minimum should be 1.')); ?></small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Maximum Purchase Qty')); ?></label>
                            <div class="col-md-8">
                                <input type="number" class="form-control" name="max_qty"
                                    value="<?php echo e($product->max_qty); ?>" min="0">
                                <small
                                    class="text-muted"><?php echo e(translate('Customer will be able to purchase this maximum quantity for this product. Default 0 for unlimited.')); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Product Images')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label" for="signinSrEmail"><?php echo e(translate('Thumbnail Image')); ?>

                                <small>(300x300)</small></label>
                            <div class="col-md-8">
                                <div class="input-group" data-toggle="aizuploader" data-type="image" data-mu>
                                    <div class="input-group-prepend">
                                        <div class="input-group-text bg-soft-secondary font-weight-medium">
                                            <?php echo e(translate('Browse')); ?></div>
                                    </div>
                                    <div class="form-control file-amount"><?php echo e(translate('Choose File')); ?></div>
                                    <input type="hidden" name="thumbnail_img" class="selected-files"
                                        value="<?php echo e($product->thumbnail_img); ?>">
                                </div>
                                <div class="file-preview box sm">
                                </div>
                                <small
                                    class="text-muted"><?php echo e(translate('This image is visible in all product box. Use 300x300 sizes image. Keep some blank space around the main object of your image as we had to crop some edge in different devices to make it responsive.')); ?></small>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"
                                for="signinSrEmail"><?php echo e(translate('Gallery Images')); ?><small>(600x600)</small></label>
                            <div class="col-md-8">
                                <div class="input-group" data-toggle="aizuploader" data-type="image"
                                    data-multiple="true">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text bg-soft-secondary font-weight-medium">
                                            <?php echo e(translate('Browse')); ?></div>
                                    </div>
                                    <div class="form-control file-amount"><?php echo e(translate('Choose File')); ?></div>
                                    <input type="hidden" name="photos" class="selected-files"
                                        value="<?php echo e($product->photos); ?>">
                                </div>
                                <div class="file-preview box sm">
                                </div>
                                <small
                                    class="text-muted"><?php echo e(translate("These images are visible in the product details page gallery. Use 600x600 or higher sizes images for better quality. But try to keep file size low as it'll increase page load time.")); ?></small>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- price and stock -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Product price, stock')); ?></h5>
                        <div class="d-flex mt-2">
                            <label class="mb-0 mr-3 ml-0"><?php echo e(translate('Variant Product')); ?></label>
                            <label class="aiz-switch aiz-switch-success mb-0">
                                <input type="checkbox" name="is_variant" onchange="is_variant_product(this)"
                                    <?php if($product->is_variant): ?> checked <?php endif; ?>>
                                <span></span>
                            </label>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php
                            $first_variation = $product->variations->first();
                            $price = !$product->is_variant ? $first_variation->price : 0;
                            $sku = !$product->is_variant ? $first_variation->sku : null;
                            $stock = !$product->is_variant ? $first_variation->stock : 1;
                        ?>

                        <div class="no_product_variant" <?php if($product->is_variant): ?> style="display:none;" <?php endif; ?>>
                            <div class="form-group row">
                                <label class="col-md-3 col-from-label"><?php echo e(translate('Regular price')); ?> <span
                                        class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <input type="number" step="0.01" min="0" value="<?php echo e($price); ?>"
                                        placeholder="<?php echo e(translate('Price')); ?>" name="price" class="form-control"
                                        required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-from-label"><?php echo e(translate('SKU')); ?></label>
                                <div class="col-md-8">
                                    <input type="test" placeholder="<?php echo e(translate('SKU')); ?>" value="<?php echo e($sku); ?>"
                                        name="sku" class="form-control">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-from-label"><?php echo e(translate('Stock')); ?> <span
                                        class="text-danger">*</span></label>
                                <div class="col-md-8">
                                    <select class="form-control aiz-selectpicker" name="stock"
                                        data-selected="<?php echo e($stock); ?>">
                                        <option value="1"><?php echo e(translate('In stock')); ?></option>
                                        <option value="0"><?php echo e(translate('Out of stock')); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="has_product_variant" <?php if(!$product->is_variant): ?> style="display:none;" <?php endif; ?>>
                            <div class="alert alert-info">
                                <?php echo e(translate('Select an option for this product and then select choices of each option. Max 3 options')); ?>

                            </div>

                            <div class="customer_choice_options">

                                <?php $__empty_1 = true; $__currentLoopData = generate_variation_options($product->variation_combinations); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $combination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="form-group row gutters-10 ">
                                        <div class="col-xxl-3 col-xl-4 col-md-5 attr-names">
                                            <select class="form-control aiz-selectpicker" name="product_options[]"
                                                onchange="get_option_choices(this)" data-live-search="true"
                                                title="<?php echo e(translate('Select an option')); ?>"
                                                data-selected="<?php echo e($combination['id']); ?>">
                                                <?php $__currentLoopData = $all_attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($attribute->id); ?>">
                                                        <?php echo e($attribute->getTranslation('name')); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col attr-values">
                                            <?php
                                                $attribute_values = \App\Models\AttributeValue::where('attribute_id', $combination['id'])->get();
                                                $old_val = array_map(function ($val) {
                                                    return $val['id'];
                                                }, $combination['values']);
                                            ?>
                                            <select class="form-control aiz-selectpicker"
                                                name="option_<?php echo e($combination['id']); ?>_choices[]" multiple
                                                data-live-search="true" onchange="update_sku()"
                                                data-selected="<?php echo e(json_encode($old_val)); ?>">
                                                <?php $__currentLoopData = $attribute_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($attribute_value->id); ?>">
                                                        <?php echo e($attribute_value->getTranslation('name')); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <?php if($key == 0): ?>
                                            <div class="col-auto">
                                                <button type="button" class="btn btn-icon btn-soft-secondary"
                                                    onclick="add_new_option()">
                                                    <i class="la-plus las opacity-70"></i>
                                                </button>
                                            </div>
                                        <?php else: ?>
                                            <div class="col-auto">
                                                <button type="button" data-toggle="remove-parent" class="btn btn-icon p-0"
                                                    data-parent=".row" onclick="update_sku()">
                                                    <i class="la-2x la-trash las opacity-70"></i>
                                                </button>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="form-group row gutters-10 ">
                                        <div class="col-xxl-3 col-xl-4 col-md-5 attr-names">
                                            <select class="form-control aiz-selectpicker" name="product_options[]"
                                                onchange="get_option_choices(this)" data-live-search="true"
                                                title="<?php echo e(translate('Select an option')); ?>">
                                                <?php $__currentLoopData = $all_attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($attribute->id); ?>">
                                                        <?php echo e($attribute->getTranslation('name')); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col attr-values">
                                            <div class="form-control">
                                                <span><?php echo e(translate('Select an option')); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-auto">
                                            <button type="button" class="btn btn-icon btn-soft-secondary"
                                                onclick="add_new_option()">
                                                <i class=" la-plus las opacity-70"></i>
                                            </button>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            </div>
                            <div class="sku_combination" id="sku_combination">
                                <?php if($product->is_variant): ?>
                                    <?php echo $__env->make('backend.product.products.sku_combinations_edit',['variations' =>
                                    $product->variations], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Product Discount')); ?></h5>
                    </div>
                    <div class="card-body">
                        <?php
                            if ($product->discount_start_date) {
                                $start_date = date('d-m-Y H:i:s', $product->discount_start_date);
                                $end_date = date('d-m-Y H:i:s', $product->discount_end_date);
                                $discount_date = $start_date . ' to ' . $end_date;
                            } else {
                                $discount_date = '';
                            }
                        ?>
                        <div class="form-group row">
                            <label class="col-sm-3 control-label"
                                for="start_date"><?php echo e(translate('Discount Date Range')); ?></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control aiz-date-range" name="date_range"
                                    placeholder="Select Date" data-time-picker="true" data-format="DD-MM-Y HH:mm:ss"
                                    data-separator=" to " value="<?php echo e($discount_date); ?>" autocomplete="off">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Discount')); ?> <span
                                    class="text-danger">*</span></label>
                            <div class="col-md-6">
                                <input type="number" lang="en" min="0" value="<?php echo e($product->discount); ?>" step="0.01"
                                    placeholder="<?php echo e(translate('Discount')); ?>" name="discount" class="form-control"
                                    required>
                            </div>
                            <div class="col-md-3">
                                <select class="form-control aiz-selectpicker" name="discount_type"
                                    data-selected="<?php echo e($product->discount_type); ?>">
                                    <option value="flat"><?php echo e(translate('Flat')); ?></option>
                                    <option value="percent"><?php echo e(translate('Percent')); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                
                <?php if(get_setting('club_point')): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0 h6"><?php echo e(translate('Club Point')); ?></h5>
                        </div>
                        <div class="card-body">
                            <div class="form-group row">
                                <label class="col-sm-3 control-label"
                                    for="start_date"><?php echo e(translate('Set Point')); ?></label>
                                <div class="col-sm-9">
                                    <input type="number" lang="en" min="0" value="<?php echo e($product->earn_point); ?>" step="1" placeholder="1" name="earn_point" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Shipping Information')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Standard delivery time')); ?></label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <input type="number" step="0.01" class="form-control" name="standard_delivery_time"
                                        min="0" value="<?php echo e($product->standard_delivery_time); ?>" required>
                                    <div class="input-group-append"><span class="input-group-text">hr(s)</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Express delivery time')); ?></label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <input type="number" step="0.01" class="form-control" name="express_delivery_time"
                                        min="0" value="<?php echo e($product->express_delivery_time); ?>" required>
                                    <div class="input-group-append"><span class="input-group-text">hr(s)</span></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Weight')); ?></label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <input type="number" step="0.01" class="form-control" name="weight" min="0"
                                        value="<?php echo e($product->weight); ?>" required>
                                    <div class="input-group-append"><span
                                            class="input-group-text"><?php echo e(get_setting('weight_unit')); ?></span></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Height')); ?></label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <input type="number" step="0.01" class="form-control" name="height" min="0"
                                        value="<?php echo e($product->height); ?>" required>
                                    <div class="input-group-append"><span
                                            class="input-group-text"><?php echo e(get_setting('dimension_unit')); ?></span></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Length')); ?></label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <input type="number" step="0.01" class="form-control" name="length" min="0"
                                        value="<?php echo e($product->length); ?>" required>
                                    <div class="input-group-append"><span
                                            class="input-group-text"><?php echo e(get_setting('dimension_unit')); ?></span></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Width')); ?></label>
                            <div class="col-md-8">
                                <div class="input-group">
                                    <input type="number" step="0.01" class="form-control" name="width" min="0"
                                        value="<?php echo e($product->width); ?>" required>
                                    <div class="input-group-append"><span
                                            class="input-group-text"><?php echo e(get_setting('dimension_unit')); ?></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Product Description')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Description')); ?> <i
                                    class="las la-language text-danger"
                                    title="<?php echo e(translate('Translatable')); ?>"></i></label>
                            <div class="col-md-8">
                                <textarea class="aiz-text-editor" name="description"><?php echo $product->getTranslation('description', $lang); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Product attributes')); ?></h5>
                        <button class="btn btn-soft-dark" type="button"
                            onclick="add_new_attribute()"><?php echo e(translate('Add new attribute')); ?></button>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <?php echo e(translate('These attributes will be used only for filtering.')); ?></div>
                        <div class="all-attributes">
                            <?php $__currentLoopData = $product->attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group row gutters-10">
                                    <div class="col-xxl-3 col-xl-4 col-md-5 attr-names">
                                        <select class="form-control aiz-selectpicker" name="product_attributes[]"
                                            onchange="get_attributes_values(this)"
                                            data-selected="<?php echo e($product_attribute->attribute_id); ?>"
                                            data-live-search="true" readonly>
                                            <option value=""><?php echo e(translate('Select an attribute')); ?></option>
                                            <?php $__currentLoopData = $all_attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($attribute->id); ?>">
                                                    <?php echo e($attribute->getTranslation('name')); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col attr-values">
                                        <?php
                                            $attribute_values = \App\Models\AttributeValue::where('attribute_id', $product_attribute->attribute_id)->get();
                                        ?>
                                        <select class="form-control aiz-selectpicker"
                                            name="attribute_<?php echo e($product_attribute->attribute_id); ?>_values[]"
                                            data-selected="<?php echo e($product->attribute_values->where('attribute_id', $product_attribute->attribute_id)->pluck('attribute_value_id')); ?>"
                                            multiple data-live-search="true">
                                            <?php $__currentLoopData = $attribute_values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attribute_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($attribute_value->id); ?>">
                                                    <?php echo e($attribute_value->getTranslation('name')); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-auto">
                                        <button type="button" data-toggle="remove-parent" class="btn btn-icon p-0"
                                            data-parent=".row">
                                            <i class="la-2x la-trash las opacity-70"></i>
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('SEO Meta Tags')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Meta Title')); ?></label>
                            <div class="col-md-8">
                                <input type="text" class="form-control" name="meta_title"
                                    placeholder="<?php echo e(translate('Meta Title')); ?>" value="<?php echo e($product->meta_title); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-from-label"><?php echo e(translate('Description')); ?></label>
                            <div class="col-md-8">
                                <textarea name="meta_description" rows="8"
                                    class="form-control"><?php echo e($product->meta_description); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"
                                for="signinSrEmail"><?php echo e(translate('Meta Image')); ?></label>
                            <div class="col-md-8">
                                <div class="input-group" data-toggle="aizuploader" data-type="image">
                                    <div class="input-group-prepend">
                                        <div class="input-group-text bg-soft-secondary font-weight-medium">
                                            <?php echo e(translate('Browse')); ?></div>
                                    </div>
                                    <div class="form-control file-amount"><?php echo e(translate('Choose File')); ?></div>
                                    <input type="hidden" name="meta_image" class="selected-files"
                                        value="<?php echo e($product->meta_image); ?>">
                                </div>
                                <div class="file-preview box sm">
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label"><?php echo e(translate('Slug')); ?></label>
                            <div class="col-md-8">
                                <input type="text" placeholder="<?php echo e(translate('Slug')); ?>" id="slug" name="slug"
                                    value="<?php echo e($product->slug); ?>" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col col-lg-auto w-lg-300px w-xxl-400px">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Product Status')); ?></h5>
                    </div>
                    <div class="card-body">
                        <select class="form-control aiz-selectpicker" name="status"
                            data-selected="<?php echo e($product->published); ?>">
                            <option value="0"><?php echo e(translate('Draft')); ?></option>
                            <option value="1" selected><?php echo e(translate('Published')); ?></option>
                        </select>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Product Brand')); ?></h5>
                    </div>
                    <div class="card-body">
                        <select class="form-control aiz-selectpicker" name="brand_id"
                            data-selected="<?php echo e($product->brand_id); ?>" data-live-search="true"
                            title="<?php echo e(translate('Select Brand')); ?>">
                            <?php $__currentLoopData = \App\Models\Brand::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Product Category')); ?></h5>
                    </div>
                    <div class="card-body ">
                        <div class="h-300px overflow-auto c-scrollbar-light">
                            <ul class="list-unstyled">
                                <?php
                                    $old_categories = $product->product_categories->pluck('category_id')->toArray();
                                ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <label class="aiz-checkbox">
                                            <input type="checkbox" value="<?php echo e($category->id); ?>" name="category_ids[]"
                                                <?php if(in_array($category->id, $old_categories)): ?> checked <?php endif; ?>>
                                            <span class="aiz-square-check"></span>
                                            <span><?php echo e($category->getTranslation('name')); ?></span>
                                        </label>
                                        <?php if(count($category->childrenCategories) > 0): ?>
                                            <ul class="list-unstyled ml-3">
                                                <?php $__currentLoopData = $category->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <label class="aiz-checkbox">
                                                            <input type="checkbox" value="<?php echo e($childCategory->id); ?>"
                                                                name="category_ids[]" <?php if(in_array($childCategory->id, $old_categories)): ?> checked <?php endif; ?>>
                                                            <span class="aiz-square-check"></span>
                                                            <span><?php echo e($childCategory->getTranslation('name')); ?></span>
                                                        </label>
                                                        <?php if(count($childCategory->childrenCategories) > 0): ?>
                                                            <ul class="list-unstyled ml-3">
                                                                <?php $__currentLoopData = $childCategory->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grandChildCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li>
                                                                        <label class="aiz-checkbox">
                                                                            <input type="checkbox"
                                                                                value="<?php echo e($grandChildCategory->id); ?>"
                                                                                name="category_ids[]"
                                                                                <?php if(in_array($grandChildCategory->id, $old_categories)): ?> checked <?php endif; ?>>
                                                                            <span class="aiz-square-check"></span>
                                                                            <span><?php echo e($grandChildCategory->getTranslation('name')); ?></span>
                                                                        </label>
                                                                    </li>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </ul>
                                                        <?php endif; ?>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Product Tags')); ?></h5>
                    </div>
                    <div class="card-body">
                        <input type="text" class="form-control aiz-tag-input" name="tags"
                            placeholder="<?php echo e(translate('Type and hit enter to add a tag')); ?>"
                            value="<?php echo e($product->tags); ?>">
                        <small class="text-muted"><?php echo e(translate('These will be used for product search.')); ?></small>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('VAT & Tax')); ?></h5>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = \App\Models\Tax::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label for="name">
                                <?php echo e($tax->name); ?>

                                <input type="hidden" value="<?php echo e($tax->id); ?>" name="tax_ids[]">
                            </label>

                            <?php
                                $tax_amount = 0;
                                $tax_type = 'flat';
                                foreach ($product->taxes as $row) {
                                    if ($row->tax_id == $tax->id) {
                                        $tax_amount = $row->tax;
                                        $tax_type = $row->tax_type;
                                    }
                                }
                            ?>

                            <div class="form-row">
                                <div class="form-group col-6">
                                    <input type="number" lang="en" min="0" value="<?php echo e($tax_amount); ?>" step="0.01"
                                        placeholder="<?php echo e(translate('Tax')); ?>" name="taxes[]" class="form-control"
                                        required>
                                </div>
                                <div class="form-group col-6">
                                    <select class="form-control aiz-selectpicker" name="tax_types[]"
                                        data-selected="<?php echo e($tax_type); ?>" required>
                                        <option value="flat"><?php echo e(translate('Flat')); ?></option>
                                        <option value="percent"><?php echo e(translate('Percent')); ?></option>
                                    </select>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0 h6"><?php echo e(translate('Warranty')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-2"><?php echo e(translate('Warranty available for this product?')); ?></div>
                        <label class="aiz-switch aiz-switch-success mb-0">
                            <input type="checkbox" name="has_warranty" <?php if($product->has_warranty): ?> checked <?php endif; ?>>
                            <span></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>
        <div class="mar-all text-right mb-3">
            <button type="submit" class="btn btn-primary"
                id="upload-product"><?php echo e(translate('Update Product')); ?></button>
        </div>
    </form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

    <script type="text/javascript">
        $(document).ready(function() {
            // $('body').addClass('side-menu-closed');
            $('.all-attributes').find('.attr-names').find('.aiz-selectpicker').siblings('.dropdown-toggle')
                .addClass("disabled");
            if ($('.customer_choice_options').find('.attr-names').find('.aiz-selectpicker').val() !== '') {
                $('.customer_choice_options').find('.attr-names').find('.aiz-selectpicker').siblings(
                    '.dropdown-toggle').addClass("disabled");
            }
        });
        $('#product_form').bind('submit', function(e) {
            // Disable the submit button while evaluating if the form should be submitted
            $("#upload-product").prop('disabled', true);

            var valid = true;

            if (!valid) {
                e.preventDefault();

                // Reactivate the button if the form was not submitted
                $("#upload-product").button.prop('disabled', false);
            }
        });

        function is_variant_product(el) {
            $(".has_product_variant").hide();
            $(".no_product_variant").hide();
            if ($(el).is(':checked')) {
                $(".has_product_variant").show();
            } else {
                $(".no_product_variant").show();
            }
        }

        function add_new_attribute() {
            $.ajax({
                type: "POST",
                data: $('#product_form').serialize(),
                url: '<?php echo e(route('product.new_attribute')); ?>',
                success: function(data) {
                    if (data.count == -1) {
                        AIZ.plugins.notify('warning', '<?php echo e(translate('Please select an attribute.')); ?>');
                    } else if (data.count > 0) {
                        $('.all-attributes').find('.attr-names').find('.aiz-selectpicker').siblings(
                            '.dropdown-toggle').addClass("disabled");
                        $('.all-attributes').append(data.view);
                        AIZ.plugins.bootstrapSelect();
                    } else {
                        AIZ.plugins.notify('info', '<?php echo e(translate('No more arrtribute found.')); ?>');
                    }
                }
            });
        }

        function get_attributes_values(e) {
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': AIZ.data.csrf
                },
                type: "POST",
                data: {
                    attribute_id: $(e).val()
                },
                url: '<?php echo e(route('product.get_attribute_values')); ?>',
                success: function(data) {
                    $(e).closest('.row').find('.attr-values').html(data);
                    AIZ.plugins.bootstrapSelect();
                }
            });
        }

        function add_new_option() {
            $.ajax({
                type: "POST",
                data: $('#product_form').serialize(),
                url: '<?php echo e(route('product.new_option')); ?>',
                success: function(data) {
                    if (data.count == -2) {
                        AIZ.plugins.notify('warning', '<?php echo e(translate('Maximum option limit reached.')); ?>');
                    } else if (data.count == -1) {
                        AIZ.plugins.notify('warning', '<?php echo e(translate('Please select an option.')); ?>');
                    } else if (data.count > 0) {
                        $('.customer_choice_options').find('.attr-names').find('.aiz-selectpicker').siblings(
                            '.dropdown-toggle').addClass("disabled");
                        $('.customer_choice_options').append(data.view);
                        AIZ.plugins.bootstrapSelect();
                    } else {
                        AIZ.plugins.notify('info', '<?php echo e(translate('No more option found.')); ?>');
                    }
                }
            });
        }

        function get_option_choices(e) {
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': AIZ.data.csrf
                },
                type: "POST",
                data: {
                    attribute_id: $(e).val()
                },
                url: '<?php echo e(route('product.get_option_choices')); ?>',
                success: function(data) {
                    $(e).closest('.row').find('.attr-values').html(data);
                    AIZ.plugins.bootstrapSelect();
                }
            });
        }

        function update_sku() {
            $.ajax({
                type: "POST",
                url: '<?php echo e(route('product.sku_combination')); ?>',
                data: $('#product_form').serialize(),
                success: function(data) {
                    $('#sku_combination').html(data);
                    setTimeout(() => {
                        AIZ.uploader.previewGenerate();
                        AIZ.plugins.bootstrapSelect('refresh');
                    }, 500);
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/schules1/a.schulesoft.com/resources/views/backend/product/products/edit.blade.php ENDPATH**/ ?>