UPDATE `settings` SET `value` = '2.1' WHERE `type` = 'current_version';

COMMIT;